1. Run `dotnet restore` to install the required packages.
2. Run `dotnet run` to build and run the simulated device application.