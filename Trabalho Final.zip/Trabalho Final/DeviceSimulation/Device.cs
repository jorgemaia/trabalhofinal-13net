﻿using System;
using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace DeviceSimulation
{
    public class Device
    {
        private static DeviceClient s_deviceClient;
        private const string s_connectionString = "HostName=TrabalhoFIAP.azure-devices.net;DeviceId=Device01;SharedAccessKey=0jPlDJXK2uuHu9fyPKBBWdKmnw8l6oehRvcwaaF2vFI=";
        private static List<Guid> lstVagasDisponiveis = new List<Guid>();
        private static List<Guid> lstVagasOcupadas = new List<Guid>();

        private static void StartRun()
        {
            for (int i = 0; i < 10; i++)
            {
                //Gerando id`s dos dispositivos no estacionamento... [Simulação de uma listagem das vagas disponíveis]
                lstVagasDisponiveis.Add(Guid.NewGuid());
            }

            Console.WriteLine("IoT Hub Quickstarts - Simulated device. Ctrl-C to exit.\n");
            
            // Connect to the IoT hub using the MQTT protocol
            s_deviceClient = DeviceClient.CreateFromConnectionString(s_connectionString, TransportType.Mqtt);

            SendDeviceToCloudUsoDeVagaMessagesAsync();
            Thread.Sleep(1000);
            SendDeviceToCloudLiberacaoDeVagaMessagesAsync();
        }

        private static async void SendDeviceToCloudUsoDeVagaMessagesAsync()
        {
            while (true)
            {
                if (lstVagasDisponiveis.Count() > 0)
                {
                    Guid deviceID = lstVagasDisponiveis.FirstOrDefault();
                    lstVagasOcupadas.Add(deviceID);
                    lstVagasDisponiveis.Remove(deviceID);
                    DateTime dateTime = DateTime.Now;
                    bool isUsed = true;

                    var vagaOcupada = new
                    {
                        deviceID = deviceID,
                        dateTime = dateTime,
                        isUsed = isUsed
                    };

                    var messageString = JsonConvert.SerializeObject(vagaOcupada);
                    var message = new Message(Encoding.ASCII.GetBytes(messageString));
                    await s_deviceClient.SendEventAsync(message).ConfigureAwait(false);
                    Console.WriteLine("{0} > Vaga ocupada: {1}", dateTime, messageString);
                }

                await Task.Delay(10000).ConfigureAwait(false);
            }
        }

        private static async void SendDeviceToCloudLiberacaoDeVagaMessagesAsync()
        {
            Random rnd = new Random();

            while (true)
            {
                if (lstVagasOcupadas.Count() > 0)
                {
                    Guid deviceID = lstVagasOcupadas.ElementAt(rnd.Next(lstVagasOcupadas.Count()));
                    lstVagasDisponiveis.Add(deviceID);
                    lstVagasOcupadas.Remove(deviceID);
                    DateTime dateTime = DateTime.Now;
                    bool isUsed = false;

                    var vagaLiberada = new
                    {
                        deviceID = deviceID,
                        dateTime = dateTime,
                        isUsed = isUsed
                    };

                    var messageString = JsonConvert.SerializeObject(vagaLiberada);
                    var message = new Message(Encoding.ASCII.GetBytes(messageString));
                    await s_deviceClient.SendEventAsync(message).ConfigureAwait(false);
                    Console.WriteLine("{0} > Vaga liberada: {1}", dateTime, messageString);
                }

                await Task.Delay(50000).ConfigureAwait(false);
            }
        }
        public static void Main(string[] args)
        {
            StartRun();
            Console.ReadKey();
        }
    }
}