using IoTHubTrigger = Microsoft.Azure.WebJobs.EventHubTriggerAttribute;

using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventHubs;
using System.Text;
using System.Net.Http;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;

namespace IoTReader
{
    public static class LerDadosVagasEstacionamento
    {
        private static HttpClient client = new HttpClient();

        [FunctionName("LerDadosVagasEstacionamento")]
        public static void Run([IoTHubTrigger("messages/events", Connection = "Conexao")]EventData message, [Table("tblVagasEstacionamento", Connection="AzureWebJobsStorage")]ICollector<Mensagem> tabela, ILogger log)
        {
            tabela.Add(new Mensagem(Encoding.UTF8.GetString(message.Body.Array)));
            log.LogInformation($"C# IoT Hub trigger function processed a message: {Encoding.UTF8.GetString(message.Body.Array)}");
        }

        public class Mensagem: TableEntity
        {
            public Mensagem(string payLoad)
            {
                this.PartitionKey = "VagasEstacionamento";
                this.RowKey = System.Guid.NewGuid().ToString();
                this.PayLoad = payLoad;
            }
            public string PayLoad { get; set; }
        }
    }
}